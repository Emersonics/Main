#ifndef UTILS
#define UTILS
#include "MyVector.h"

class Utils
{
public:
	static MyVector offset;
	static MyVector P6ToSFMLPoint(MyVector v);
};

#endif // !UTILS
