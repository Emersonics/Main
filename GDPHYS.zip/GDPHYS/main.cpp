//Created by Emerson Paul P. Celestial

#include <iostream>
#include <SFML/Graphics.hpp>
#include <chrono>
#include <stddef.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <list>
#include "Assignments/MyParticle.h"
#include "Assignments/MyVector.h"
#include "Assignments/Utils.h"
#include "Assignments/PhysicsWorld.h"
#include "Assignments/RenderParticle.h"
#define PI 3.14159265

using namespace std::chrono_literals;
using namespace std::chrono;

//16ms = 1 frame in a 60fps
constexpr nanoseconds timestep(16ms);

void instantiateParticle(int mass, MyVector velocity, MyVector acceleration, MyVector position, 
    list<RenderParticle*>& RenderParticles, PhysicsWorld& pWorld);
float RandomFloat(float a, float b);


int main() {
    sf::RenderWindow window(sf::VideoMode(700, 500), "P6 Test", sf::Style::Default);

    //PhysicsWorld, Renderparticle, and Utils instance
    PhysicsWorld pWorld = PhysicsWorld();
    std::list<RenderParticle*> RenderParticles;
    Utils::offset = MyVector(0, 250);

    //GameState
    bool allAreFinished = false;
    std::string rankings[3] = { "","","" };
    //renderPoint instance
    MyVector renderPoint4;
    //Circle Shapes instance

    //Physics world called functions
    //clock/frame 
    using clock = high_resolution_clock;
    auto curr_time = clock::now();
    auto prev_time = curr_time;
    nanoseconds curr_ns(0ns);

    sf::Event event;

    while (!allAreFinished) {
        curr_time = clock::now();
        auto dur = duration_cast<nanoseconds> (curr_time - prev_time);
        prev_time = curr_time;

        curr_ns += dur;
        if (curr_ns >= timestep) {
            auto ms = duration_cast<milliseconds>(curr_ns);

            //Call the update when it reaches a cetain timestep
            //ms is in milisecs while engine is using secs so we divide by 1000
            //(float)ms.count() / 1000
            //Updates the shapes

            while (RenderParticles.size() < 25)
            {
                instantiateParticle(1, MyVector(0, 0), MyVector(0, 0), MyVector(350, 250), RenderParticles, pWorld);
            }

            pWorld.Update((float)ms.count() / 1000);

            curr_ns -= timestep;

            while (window.pollEvent(event))
            {
                switch (event.type)
                {
                case sf::Event::Closed:
                    window.close();
                    break;
                }
            }

            window.clear();
            //iterates the particles
            for (std::list<RenderParticle*>::iterator i = RenderParticles.begin();
                i != RenderParticles.end(); i++)
            {
                (*i)->Draw(&window);
            }
            window.display();
        }
    }
    system("pause");
    return 0;
}

void instantiateParticle(int mass, MyVector velocity, MyVector acceleration, 
    MyVector position, list<RenderParticle*>& RenderParticles, PhysicsWorld& pWorld)
{
    srand(time(NULL));
    MyParticle particle = MyParticle(mass, position, velocity, acceleration, 8.0f); //particle
    sf::CircleShape shape(10);  //shape

    //set the random color of the fireballs
    int randomColor;
    randomColor = rand()%3;
    switch (randomColor)
    {
    case 1:
        shape.setFillColor(sf::Color::Red);
        break;
    case 2:
        shape.setFillColor(sf::Color::Blue);
        break;
    case 3:
        shape.setFillColor(sf::Color::White);
        break;
    }

    //set the starting position
    MyVector renderPoint = particle.GetRenderPoint();
    shape.setPosition(renderPoint.x, renderPoint.y);

    //random addForce
    float randomX;
    randomX = RandomFloat(-0.3, 0.3);
    particle.AddForce(MyVector(randomX * 9000, -1 * 16000));

    //add particle to the PhysicWorld
    pWorld.addParticle(&particle);

    //set the renderPoint of the particle
    RenderParticle p = RenderParticle(&particle, &shape);
    RenderParticles.push_back(&p);

}


float RandomFloat(float a, float b) 
{
    float random = ((float)rand()) / (float)RAND_MAX;
    float diff = b - a;
    float r = random * diff;
    return a + r;
}

